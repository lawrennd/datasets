% DATASETS toolbox
% Version 0.133		05-Oct-2008
% Copyright (c) 2008, Neil D. Lawrence
% 
, Neil D. Lawrence
% MOCAPLOADTEXTDATA Load a motion capture data set from a text file.
% LVMLOADDATA Load a latent variable model dataset.
% MOCAPCONNECTIONS Give a connection matrix for the motion capture data.
% MOCAPPARSETEXT Parse a motion capture text file.
% MAPLOADDATA Load a mapping model dataset (e.g. classification, regression).
% GENERATECRESCENTDATA Generate crescent data.
% PARSENOBLEKERNELFILE Parse a kernel file from Bill Stafford Noble.
% PARSEWIRELESSDATA Load wireless strength data.
% XLSLOADDATA Wrapper function for xlsread to get files from the datasets directory.
% DATASETSDIRECTORY Returns directory where data is stored.
