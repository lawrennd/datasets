function [data, names] = xlsLoadData(fileName, sheetName)

% XLSLOADDATA Wrapper function for xlsread to get files from the datasets directory.
%
%	Description:
%	[data, names] = xlsLoadData(fileName, sheetName)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	xlsLoadData.m version 1.1


baseDir = datasetsDirectory;
[data, names] = xlsread([baseDir fileName], sheetName);
