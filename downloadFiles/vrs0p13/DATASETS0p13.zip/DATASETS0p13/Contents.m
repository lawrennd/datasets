% DATASETS toolbox
% Version 0.13		Friday 03 Nov 2006 at 14:23
% Copyright (c) 2006 Neil D. Lawrence
% 
% DATASETSDIRECTORY Returns directory where data is stored.
% LVMLOADDATA Load a latent variable model dataset.
% MAPLOADDATA Load a mapping model dataset (e.g. classification, regression).
% MOCAPCONNECTIONS Give a connection matrix for the motion capture data.
% MOCAPLOADTEXTDATA Load a motion capture data set from a text file.
% MOCAPPARSETEXT Parse a motion capture text file.
% PARSENOBLEKERNELFILE Parse a kernel file from Bill Stafford Noble.
% PARSEWIRELESSDATA Load wireless strength data.
% XLSLOADDATA Wrapper function for xlsread to get files from the datasets directory.
