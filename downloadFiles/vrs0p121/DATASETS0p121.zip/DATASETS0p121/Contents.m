% DATASETS toolbox
% Version 0.121		Saturday 18 Feb 2006 at 21:34
% Copyright (c) 2006 Neil D. Lawrence
% 
% DATASETSDIRECTORY Returns directory where data is stored.
% LVMLOADDATA Load a dataset.
% MAPLOADDATA Load a dataset.
% MOCAPCONNECTIONS Give a connection matrix for the motion capture data.
% MOCAPLOADDATA Load a motion capture dataset.
% MOCAPPARSETEXT Parse a motion capture text file.
% PARSENOBLEKERNELFILE Load wireless strength data.
% PARSEWIRELESSDATA Load wireless strength data.
% XLSLOADDATA Wrapper function for xlsread to get files from the datasets directory.
