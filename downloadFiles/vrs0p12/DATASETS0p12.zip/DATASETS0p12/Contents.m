% DATASETS toolbox
% Version 0.12		Friday 20 Jan 2006 at 18:42
% Copyright (c) 2006 Neil D. Lawrence
% 
% LVMLOADDATA Load a dataset.
% MOCAPCONNECTIONS Give a connection matrix for the motion capture data.
% MOCAPLOADDATA Load a motion capture dataset.
% MOCAPPARSETEXT Parse a motion capture text file.
% PARSEWIRELESSDATA Load wireless strength data.
% PARSENOBLEKERNELFILE Load wireless strength data.
% MAPLOADDATA Load a dataset.
% XLSLOADDATA Wrapper function for xlsread to get files from the datasets directory.
% DATASETSDIRECTORY Returns directory where data is stored.
