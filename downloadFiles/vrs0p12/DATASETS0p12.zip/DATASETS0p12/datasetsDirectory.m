function dir = datasetsDirectory

% DATASETSDIRECTORY Returns directory where data is stored.
%
% dir = datasetsDirectory
%

% Copyright (c) 2006 Neil D. Lawrence
% datasetsDirectory.m version 1.1



% by default return the directory where this file is.
fullSpec = which('datasetsDirectory');
ind = max(find(fullSpec == filesep));
dir = fullSpec(1:ind);
