function [Y, lbls] = lvmLoadData(dataset)

% LVMLOADDATA Load a dataset.
%
% [Y, lbls] = lvmLoadData(dataset)
%

% Copyright (c) 2006 Neil D. Lawrence
% lvmLoadData.m version 1.4



% get directory
baseDir = datasetsDirectory;

lbls = [];
switch dataset
 
 case 'robotWireless'
  Y = parseWirelessData([baseDir 'uw-floor.txt']);
  Y = Y(1:215, :);
 
 case 'robotWirelessTest'
  Y = parseWirelessData([baseDir 'uw-floor.txt']);
  Y = Y(216:end, :);

 case 'robotTraces'
  Y = csvread([baseDir 'Trace-3rdFloor-01.uwar.slam'], 1, 0); 
  Y = Y(1:floor(end/2), 4:end);
  Y(find(Y==-100))=-92;
  Y = (Y + 85)/15;
 case 'robotTracesTest'
  Y = csvread([baseDir 'Trace-3rdFloor-01.uwar.slam'], 1, 0); 
  Y = Y(ceil(end/2):end, 4:end);
  Y(find(Y==-100))=-92;
  Y = (Y + 85)/15;
 case 'vowels'
  load([baseDir 'jon_vowel_data']);
  Y = [a_raw; ae_raw; ao_raw; ...
       e_raw; i_raw; ibar_raw; ...
       o_raw; schwa_raw; u_raw];
  Y(:, [13 26]) = [];
  lbls = [];
  for i = 1:9
    lbl = zeros(1, 9);
    lbl(i) = 1;
    lbls = [lbls; repmat(lbl, size(a_raw, 1), 1)];
  end
 

 case 'stick'
  Y = mocapLoadTextData([baseDir 'run1']);
  Y = Y(1:4:end, :);
 
 case 'walkSitJog'
  Y = mocapLoadTextData([baseDir 'walkSitJog']);
  Y = Y(1:4:end, :)*200;
 
 case 'brendan'
  load([baseDir 'frey_rawface.mat']);
  Y = double(ff)';
  
 case 'digits'
  
  % Fix seeds
  randn('seed', 1e5);
  rand('seed', 1e5);

  load([baseDir 'usps_train.mat']);
  % Extract 600 of digits 0 to 4
  [ALL_T, sortIndices] = sort(ALL_T);
  ALL_DATA = ALL_DATA(sortIndices(:), :);
  Y = [];
  lbls = [];
  numEachDigit = 600;
  for digit = 0:4;
    firstDigit = min(find(ALL_T==digit));
    Y = [Y; ALL_DATA(firstDigit:firstDigit+numEachDigit-1, :)];
    lbl = zeros(1, 5);
    lbl(digit+1) = 1;
    lbls = [lbls; repmat(lbl, numEachDigit, 1)];
  end

 case 'twos'  
  % load data
  load([baseDir 'twos']);
  Y = 2*a-1;

 case 'oil'
  load([baseDir '3Class.mat']);
  Y = DataTrn;
  lbls = DataTrnLbls;

 case 'oilTest'
  load([baseDir '3Class.mat']);
  Y = DataTst;
  lbls = DataTstLbls;

 case 'oilValid'
  load([baseDir '3Class.mat']);
  Y = DataVdn;
  lbls = DataVdnLbls;

 case 'oil100'
  randn('seed', 1e5);
  rand('seed', 1e5);
  load([baseDir '3Class.mat']);
  Y = DataTrn;
  lbls = DataTrnLbls;
  indices = randperm(size(Y, 1));
  indices = indices(1:100);
  Y = Y(indices, :);
  lbls = lbls(indices, :);

 case 'swissRoll'
  load([baseDir 'swiss_roll_data']);
  Y = X_data(:, 1:1000)';
 
 
 otherwise
  error('Unknown data set requested.')
 
end
