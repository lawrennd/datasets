DATASETS software
Version 0.1		Wednesday 30 Nov 2005 at 01:26
Copyright (c) 2005 Neil D. Lawrence

This toolbox stores datasets and gives commands for accessing them.

Version 0.1
-----------

First release.

MATLAB Files
------------

Matlab files associated with the toolbox are:

lvmLoadData.m: Load a dataset.
mappingLoadData.m: Load a regression or classification dataset.
mocapConnections.m: Give a connection matrix for the motion capture data.
mocapLoadTextData.m: Load a motion capture dataset.
mocapParseText.m: Parse a motion capture text file.
