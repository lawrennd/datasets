% DATASETS toolbox
% Version 0.1		Wednesday 30 Nov 2005 at 01:26
% Copyright (c) 2005 Neil D. Lawrence
% 
% LVMLOADDATA Load a dataset.
% MAPPINGLOADDATA Load a regression or classification dataset.
% MOCAPCONNECTIONS Give a connection matrix for the motion capture data.
% MOCAPLOADDATA Load a motion capture dataset.
% MOCAPPARSETEXT Parse a motion capture text file.
