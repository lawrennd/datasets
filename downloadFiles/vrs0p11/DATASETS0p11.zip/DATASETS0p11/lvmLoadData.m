function [Y, lbls] = lvmLoadData(dataset)

% LVMLOADDATA Load a dataset.
%
% [Y, lbls] = lvmLoadData(dataset)
%

% Copyright (c) 2005 Neil D. Lawrence
% lvmLoadData.m version 1.3



lbls = [];
switch dataset
 
 case 'robotWireless'
  Y = parseWirelessData('uw-floor.txt');
  Y = Y(1:215, :);
 case 'robotWirelessTest'
  Y = parseWirelessData('uw-floor.txt');
  Y = Y(216:end, :);
  
 case 'vowels'
  load('jon_vowel_data');
  Y = [a_raw; ae_raw; ao_raw; ...
       e_raw; i_raw; ibar_raw; ...
       o_raw; schwa_raw; u_raw];
  Y(:, [13 26]) = [];
  lbls = [];
  for i = 1:9
    lbl = zeros(1, 9);
    lbl(i) = 1;
    lbls = [lbls; repmat(lbl, size(a_raw, 1), 1)];
  end
 
 case 'stick'
  Y = mocapLoadTextData('run1');
  Y = Y(1:4:end, :);
 
 case 'brendan'
  load frey_rawface.mat
  Y = double(ff)';
  
 case 'digits'
  
  % Fix seeds
  randn('seed', 1e5);
  rand('seed', 1e5);

  load usps_train.mat
  % Extract 600 of digits 0 to 4
  [ALL_T, sortIndices] = sort(ALL_T);
  ALL_DATA = ALL_DATA(sortIndices(:), :);
  Y = [];
  lbls = [];
  numEachDigit = 600;
  for digit = 0:4;
    firstDigit = min(find(ALL_T==digit));
    Y = [Y; ALL_DATA(firstDigit:firstDigit+numEachDigit-1, :)];
    lbl = zeros(1, 5);
    lbl(digit+1) = 1;
    lbls = [lbls; repmat(lbl, numEachDigit, 1)];
  end

 case 'twos'  
  % load data
  load twos
  Y = 2*a-1;

 case 'oil'
  load 3Class.mat
  Y = DataTrn;
  lbls = DataTrnLbls;

 case 'oil100'
  randn('seed', 1e5);
  rand('seed', 1e5);
  load 3Class.mat
  Y = DataTrn;
  lbls = DataTrnLbls;
  indices = randperm(size(Y, 1));
  indices = indices(1:100);
  Y = Y(indices, :);
  lbls = lbls(indices, :);

 case 'swissRoll'
  load swiss_roll_data
  Y = X_data(:, 1:1000)';
 otherwise
  error('Unknown data set requested.')
  
end
