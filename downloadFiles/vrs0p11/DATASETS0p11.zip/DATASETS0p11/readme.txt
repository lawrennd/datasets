DATASETS software
Version 0.11		Tuesday 27 Dec 2005 at 18:13
Copyright (c) 2005 Neil D. Lawrence

This toolbox stores datasets and gives commands for accessing them.

Version 0.11
------------

Added motion capture from Ohio State of a man running and vowel data from Jon Malkin at University of Washington.

Version 0.1
-----------

First release.

MATLAB Files
------------

Matlab files associated with the toolbox are:

lvmLoadData.m: Load a dataset.
mapLoadData.m: Load a dataset.
mappingLoadData.m: Load a regression or classification dataset.
mocapConnections.m: Give a connection matrix for the motion capture data.
mocapLoadTextData.m: Load a motion capture dataset.
mocapParseText.m: Parse a motion capture text file.
parseNobleKernelFile.m: Load wireless strength data.
parseWirelessData.m: Load wireless strength data.
